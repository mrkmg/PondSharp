using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using PondSharp.UserScripts;

namespace PondSharp.Examples
{
    /// <summary>
    /// This entity moves randomly.
    /// </summary>
    [PondDefaults(Name = "Burn Effect")]
    public class SelfExpiring : Simple
    {
        private static int _startAge = 80;
        
        [PondAdjustable(Min = 5, Max=240, Name = "Age")]
        private static int StartAge
        {
            get => _startAge;
            set
            {
                _startAge = value;
                Colors = CreateAgeColor();
            }
        }
        
        private int RemainingLife;
        private int Age;
        
        protected override void OnCreated()
        {
            base.OnCreated();
            Age = 0;
            RemainingLife = StartAge;
        }

        protected override void Tick()
        {
            // Because the change of the age will
            // change the length of the Colors
            // array, we need to ensure we do not
            // try to change the color past colors
            // that are available.
            if (Colors.Count <= Age)
            {
                Destroy();
                return;
            }
            
            ChangeColor(Colors[Age]);
            Age++;
            if (--RemainingLife <= 0)
            {
                Destroy();
                return;
            }

            if (Random.Next(10) == 0)
                ResetPower();
            
            base.Tick();

        }
        
        private const double Break1 = 0.4;
        private const double Break2 = 0.4;
        private static readonly Color Color1 = System.Drawing.Color.FromArgb(unchecked((int)0xff4f0711));
        private static readonly Color Color2= System.Drawing.Color.Firebrick;
        private static readonly Color Color3 = System.Drawing.Color.Yellow;
        private static readonly Color Color4 = System.Drawing.Color.Black;
        private static List<int> Colors = CreateAgeColor();
        
        private static List<int> CreateAgeColor()
        {
            var break1 = (int)(StartAge * Break1);
            var break2 = (int)(StartAge * Break2);
            var break3 = StartAge - (break1 + break2);
            
            return GenerateSequence(Color1, Color2, break1)
                .Concat(GenerateSequence(Color2, Color3, break2 + 1).Skip(1))
                .Concat(GenerateSequence(Color3, Color4, break3 + 1).Skip(1))
                .Select(x => x.ToArgb())
                .ToList();
        }
        
        private static List<Color> GenerateSequence(Color start, Color end, int colorCount)
        {
            var ret = new List<Color>();

            // linear interpolation lerp (r,a,b) = (1-r)*a + r*b = (1-r)*(ax,ay,az) + r*(bx,by,bz)
            for (var n = 0; n < colorCount; n++)
            {
                var r = (double)n / (double)(colorCount - 1);
                var nr = 1.0 - r;
                var A = (nr * start.A) + (r * end.A);
                var R = (nr * start.R) + (r * end.R);
                var G = (nr * start.G) + (r * end.G);
                var B = (nr * start.B) + (r * end.B);

                ret.Add(System.Drawing.Color.FromArgb((byte)A, (byte)R, (byte)G, (byte)B));
            }

            return ret;
        }
    }
    
    
}