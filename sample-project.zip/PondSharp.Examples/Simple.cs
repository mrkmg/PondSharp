using System;
using PondSharp.UserScripts;

namespace PondSharp.Examples
{
    /// <summary>
    /// The simplest example of an entity.
    /// </summary>
    [PondDefaults(InitialCount = 0, NewCount = 500)]
    public class Simple : BaseEntity
    {
        [PondAdjustable(Min = 1, Max = 100, Name = "Speed")]
        private static int StartingSpeed { get; set; } = 20;
        
        private double PowerX;
        private double PowerY;
        private double CurrentX;
        private double CurrentY;
        
        protected override void OnCreated()
        {
            ResetPower();
        }
        
        protected override void Tick()
        {
            CurrentX += PowerX;
            CurrentY += PowerY;
            if (Math.Abs(CurrentX) > 1)
            {
                ForceX = (int)CurrentX;
                CurrentX -= ForceX;
            }
            else
            {
                ForceX = 0;
            }
            if (Math.Abs(CurrentY) > 1)
            {
                ForceY = (int)CurrentY;
                CurrentY -= ForceY;
            }
            else
            {
                ForceY = 0;
            }
            
            if (!MoveTo(X + ForceX, Y + ForceY))
            {
                ResetPower();
            }
        }

        protected void ResetPower()
        {
            var direction = Math.PI * 2 * Random.NextDouble();
            PowerX = Math.Cos(direction) * (StartingSpeed/100.0);
            PowerY = Math.Sin(direction) * (StartingSpeed/100.0);
            ForceX = 0;
            ForceY = 0;
            CurrentX = 0;
            CurrentY = 0;
        }
    }
}